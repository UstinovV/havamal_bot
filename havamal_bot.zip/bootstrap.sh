pip install -r requirements.txt
python havamal.py 172517273:AAHkVkQoe-FvfVXPi6uUeDjR4N_s_gFQN3U
